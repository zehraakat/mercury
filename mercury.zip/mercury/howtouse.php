<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Mercüry</title>
        <link rel="icon" href="styles/images/favicon.ico">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="styles/customboots.css">
    </head>
    <body id="bootstrap-overrides">
        <!-- Navigation bar -->
        <nav class="navbar navbar-expand-md navbar-expand-sm bg-dark">
            <div class="container-fluid">
              <a class="navbar-brand" href="index.html">
                <img src="styles/images/favicon.ico" alt="Logo" width="30" height="30" class="d-inline-block align-text-top">
                <span class="mottos-pan">Mercüry</span>
              </a>
              <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
              </button>
              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                  <li class="nav-item">
                    <a class="nav-link nav-look" href="creatorzone.html">Create Somethin'</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link nav-look" href="howtouse.php">How 2 Use</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
      <div style="font-family: 'Press Start 2P', cursive; margin:3% 4% 3% 4%">
        <p style="color: #9c27b0">To create music u have to click <span style="color: #ffff00">Create Somethin' </span><br>u dont have to sign up <span style="color: #ffff00">Mercüry main page</span> but its a useful thing to do
        in this section u will be find 4 types of enstruments which is:</p>
        <ul style="color: #ffff00"><li>drums</li><li>saxophone</li><li>electro guitar</li><li>synth</li></ul>
        <p style="color: #9c27b0">all enstruments <span style="color: #ffff00">(except drums) </span>are listed through their notes
        u supposed to see letters on button these letters are represents ur notes in the keyboard
        which is in a Q keyboard ull notice that its easier to use cause it only contains 2 rows of letters
        theres also a note section which helpes u while u create ur own sound patterns
        theres two white button on the left down side of the screen
        one contains a red circle which looks like a japan flag that one is for record
        the other one is a upside-down triangle and its for downloading the music u just created
        u can record for a minute and check ur recording from the audio seeker section which is left on the two buttons
        be aware of the note that is bottom of the screen and enjoy the website :)</p>
      </div>

      <?php 
      
      
      
      ?>

    </body>
</html>