//Detecting Button Press
var numberOfButtons = document.querySelectorAll(".enstrumant").length;

for (var i = 0; i < numberOfButtons; i++) {
  document.querySelectorAll(".enstrumant")[i].addEventListener("click", function() {
    var buttonInnerHTML = this.innerHTML;
    makeSound(buttonInnerHTML);
    buttonAnimation(buttonInnerHTML);
  });
}

// Detecting Keyboard Press
document.addEventListener("keydown",function(event){
   makeSound(event.key);
   buttonAnimation(event.key);
 });

function makeSound(key){
  switch (key) {
    case "q":
      var tom1 = new Audio('sounds/drums/tom-1.mp3');
      tom1.play();
      break;
    case "w":
      var tom2 = new Audio('sounds/drums/tom-2.mp3');
      tom2.play();
      break;
    case "e":
      var tom3 = new Audio('sounds/drums/tom-3.mp3');
      tom3.play();
      break;
    case "r":
      var tom4 = new Audio('sounds/drums/tom-4.mp3');
      tom4.play();
      break;
    case "t":
      var snare = new Audio('sounds/drums/snare.mp3');
      snare.play();
      break;
    case "y":
      var crash = new Audio('sounds/drums/crash.mp3');
      crash.play();
      break;
    case "u":
      var kick = new Audio('sounds/drums/kick.mp3');
      kick.play();
      break;
    case "a":
      var synth_0 = new Audio('sounds/synth/synth-0.m4a');
      synth_0.play();
      break;
    case "s":
      var synth_1 = new Audio('sounds/synth/synth-1.m4a');
      synth_1.play();
      break;
    case "d":
      var synth_2 = new Audio('sounds/synth/synth-2.m4a');
      synth_2.play();
      break;
    case "f":
      var synth_3 = new Audio('sounds/synth/synth-3.m4a');
      synth_3.play();
      break;      
    case "g":
      var synth_4 = new Audio('sounds/synth/synth-4.m4a');
      synth_4.play();
      break;
    case "h":
      var synth_5 = new Audio('sounds/synth/synth-5.m4a');
      synth_5.play();
      break;
    case "j":
      var synth_6 = new Audio('sounds/synth/synth-6.m4a');
      synth_6.play();
      break;
    case "k":
      var synth_7 = new Audio('sounds/synth/synth-7.m4a');
      synth_7.play();
      break;
    case "l":
      var synth_8 = new Audio('sounds/synth/synth-8.m4a');
      synth_8.play();
      break;
    case "i":
      var synth_9 = new Audio('sounds/synth/synth-9.m4a');
      synth_9.play();
      break;
    case "Q":
      var sp_0 = new Audio('sounds/saxophone/s-0.m4a');
      sp_0.play();
      break;
    case "W":
      var sp_1 = new Audio('sounds/saxophone/s-1.m4a');
      sp_1.play();
      break;
    case "E":
      var sp_2 = new Audio('sounds/saxophone/s-2.m4a');
      sp_2.play();
      break;
    case "R":
      var sp_3 = new Audio('sounds/saxophone/s-3.m4a');
      sp_3.play();
      break;
    case "T":
      var sp_4 = new Audio('sounds/saxophone/s-4.m4a');
      sp_4.play();
      break;
    case "Y":
      var sp_5 = new Audio('sounds/saxophone/s-5.m4a');
      sp_5.play();
      break;
    case "U":
      var sp_6 = new Audio('sounds/saxophone/s-6.m4a');
      sp_6.play();
      break;
    case "I":
      var sp_7 = new Audio('sounds/saxophone/s-7.m4a');
      sp_7.play();
      break;
    case "O":
      var sp_8 = new Audio('sounds/saxophone/s-8.m4a');
      sp_8.play();
      break;
    case "P":
      var sp_9 = new Audio('sounds/saxophone/s-9.m4a');
      sp_9.play();
      break;
    case "A":
      var e_0 = new Audio('sounds/electro/electro-0.m4a');
      e_0.play();
      break;
    case "S":
      var e_1 = new Audio('sounds/electro/electro-1.m4a');
      e_1.play();
      break;
    case "D":
      var e_2 = new Audio('sounds/electro/electro-2.m4a');
      e_2.play();
      break;
    case "F":
      var e_3 = new Audio('sounds/electro/electro-3.m4a');
      e_3.play();
      break;
    case "G":
      var e_4 = new Audio('sounds/electro/electro-4.m4a');
      e_4.play();
      break;
    case "H":
      var e_5 = new Audio('sounds/electro/electro-5.m4a');
      e_5.play();
      break;
    case "J":
      var e_6 = new Audio('sounds/electro/electro-6.m4a');
      e_6.play();
      break;
    case "K":
      var e_7 = new Audio('sounds/electro/electro-7.m4a');
      e_7.play();
      break;
    case "L":
      var e_8 = new Audio('sounds/electro/electro-8.m4a');
      e_8.play();
      break;
    case "Z":
      var e_9 = new Audio('sounds/electro/electro-9.m4a');
      e_9.play();
      break;
    default:
      console.log(buttonInnerHTML);
  }
}

function buttonAnimation(currentKey){
var activeButton =  document.querySelector("." + currentKey);
activeButton.classList.add("pressed");
setTimeout(function(){
  activeButton.classList.remove("pressed");
}, 200);
}

document.getElementById("audio_rec_button").addEventListener("click", function(){
  recording();
  var isRec = document.querySelector(".rec_red");
  isRec.classList.add("pressed");
  setTimeout(function(){
  isRec.classList.remove("pressed");
  }, 3000);
 });

function recording(){

  navigator.mediaDevices.getUserMedia({ audio: true })
  .then(stream => {
    const mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.start();

    const audioChunks = [];
    mediaRecorder.addEventListener("dataavailable", event => {
      audioChunks.push(event.data);
      mediaRecorder.addEventListener("stop", () => {
        const audioBlob = new Blob(audioChunks);
        const audioUrl = URL.createObjectURL(audioBlob);
        const audio = new Audio(audioUrl);
        audio.play();
      });
    });

    setTimeout(() => {
      mediaRecorder.stop();
    }, 3000);
  });
  return audioChunks;
}


//all this code above is for download and creating an url and listening it on the audio tag but i cant trigger the button click i think

document.querySelector('download_btn').addEventListener('click',function(){
  alert("u are about to download the track: " + track_name);
  var isRec = document.querySelector("#down_btn");
  isRec.classList.add("pressed");
  setTimeout(function(){
  isRec.classList.remove("pressed");
  }, 3000);
  download_listen();
});


//this function makes url again and a track name if u wanna download and u can reach ur track in audio tag thanks to this
function download_listen(){
      //we r creatin the url in here again in order to use it in here, there are more practical ways but it is okay as long as it works:)
      const audioBlob = new Blob(audioChunks);
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      // wrote all program down in english but used in here GMT timezone in order to we can use without errors, though idk if it would still worked all well on UTC
      const track_name = ('/sounds/tracks' + new Date().toGMTString() + '.wav').toString();
      alert("You are about to download the" + audioUrl);
      // Prepare the playback
      document.getElementById('a_controls').setAttribute('src', audio);
      // Prepare the download link
      document.getElementById('down-a').setAttribute('href', audio);
      document.getElementById('down-a').setAttribute('download', track_name);
      return track_name;
}