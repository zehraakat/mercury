//for the index carousel
  $('.carousel').carousel();
